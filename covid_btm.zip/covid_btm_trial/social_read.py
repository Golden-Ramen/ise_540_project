

'''
Twitter function
'''

def get_twitter_text(data):
    try:
        text = data["combined_tweet_txt"]
    except:
        text = ""

    return text

